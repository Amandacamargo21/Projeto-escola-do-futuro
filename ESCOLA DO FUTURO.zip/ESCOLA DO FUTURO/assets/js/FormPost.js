export class FormPost {

    constructor(idForm, idTextarea, ListPost) {
        this.form = document.getElementById(idForm)
        this.textarea = document.getElementById(idTextarea)
        this.listPost = document.getElementById(ListPost)
        this.addSubmit();
    }

    formValidade (value) {
        if(value == '' || value == null || value == undefined || value.length < 1) {
            return false;
        }
        return true;
    }

    onSubmit(func){
        this.form.addEventListener("submit", func)
    }
    
    addSubmit() {
        const handleSubmit = (event) => {
            event.preventDefault();

            if (this.formValidade(this.textarea.value)) {

            const newPost = document.createElement('li');
            newPost.classList.add('post');
            const time = this.getTime(); 
            newPost.innerHTML = `
            <div class="infoUserPost">
            <div class="imgUserPost"></div>

                <div class="nameAndHour">
                    <strong>Amanda Camargo</strong>
                    <p>${time}</p>
                </div>
            </div>
            <p>
            ${this.textarea.value}
            </p>

            <div class="actionBtnPost">
                <button type="button" class="filesPost like">
                    <img src="/assets/img/coracao.png" alt="Curtir">Curtir
                    </button>
                <button type="button" class="filesPost comment">
                    <img src="/assets/img/bate-papo.png" alt="Comentar">Comentar
                    </button>
                <button type="button" class="filesPost share">
                    <img src="/assets/img/enviar.png" alt="Compartilhar">Compartilhar
                </button>
            </div>
            
            `;
            this.listPost.appendChild(newPost);
            history.textarea.value = "";
        }
        else {
            alert('Verifique o campo digitado.')
        }
        }

        this.onSubmit(handleSubmit);
    }

    getTime () {
        const time = new Date();
        const hour = time.getHours();
        const minutes = time.getMinutes();
        const day = time.getDay();
        const month = time.getMonth();
        const year = time.getFullYear();


        return `${hour}:${minutes} ${day}/${month}/${year}`
    }

}

const postForm = new FormPost('formPost', 'textarea', 'posts')