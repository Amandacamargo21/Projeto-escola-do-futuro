const form = document.getElementById("form");
const materia = document.getElementById("materia");
const tema = document.getElementById("tema");
const data = document.getElementById("data");

form.addEventListener("submit", (e) => {
  e.preventDefault();

  checkInputs();
});

function checkInputs() {
  const materiaValue = materia.value;
  const temaValue = tema.value;
  const dataValue = data.value;

  if (materiaValue === "") {
    setErrorFor(materia, "Campo obrigatório");
  } else {
    setSuccessFor(materia);
  }

  if (temaValue === "") {
    setErrorFor(tema, "O tema é obrigatório");
  } else {
    setSuccessFor(tema);
  }

  if (dataValue === "") {
    setErrorFor(data, "A data é obrigatória.");
  } else {
    setSuccessFor(data);
  }

  const formControls = form.querySelectorAll("form-control");
  const formIsValid = [...formControls].every((formControl) => {
    return formControl.className === "form-control success";
  });
  if (formIsValid) {
    alert("Atividade postada com sucesso! :)");
  }
}

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector("small");

  //Adiciona a mensagem de erro

  small.innerText = message;

  //Adiciona a classe de erro

  formControl.className = "form-control error";
}

function setSuccessFor(input) {
  const formControl = input.parentElement;

  // Adicionar a classe de sucesso
  formControl.className = "form-control success";
}
